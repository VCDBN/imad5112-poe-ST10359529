package com.nehaar.imadpart1

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class StatsFunction : AppCompatActivity() {

    private var numArray = ArrayList<Int>()
    private lateinit var tvMemory: TextView
    private lateinit var tvAnswers: TextView
    private lateinit var buttonAvg: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stats_function)

        tvMemory = findViewById<TextView>(R.id.tvMemory)
        tvAnswers = findViewById<TextView>(R.id.tvAnswers)
        buttonAvg = findViewById<Button>(R.id.buttonAvg)

        Log.i("Testing","OnCreate Works");

        var edtEnter = findViewById<TextView>(R.id.edtEnter)
        var buttonAdd = findViewById<Button>(R.id.buttonAdd)
        var buttonClr = findViewById<Button>(R.id.buttonClr)
        var buttonMinMax = findViewById<Button>(R.id.buttonMinMax)


        buttonAdd.setOnClickListener {
            var value = edtEnter.text.toString()

            if (value.isNotEmpty()) {
                val value = value.toIntOrNull()

                if (value != null) {
                    numArray.add(value)
                    edtEnter.text = ""
                    displayArrayContents()
                }
            }
        }

        edtEnter.setOnClickListener {
            clear()
        }

        buttonMinMax.setOnClickListener {
            MinMax()
        }

        buttonAvg.setOnClickListener {
            Average()
        }
    }

    private fun displayArrayContents() {
        var arrayContent = StringBuilder()

        for (value in numArray) {
            arrayContent.append(value).append("\n")
        }
        tvMemory.text = arrayContent.toString()

    }

    private fun MinMax() {
        if (numArray.isNotEmpty()) {
            val min = numArray.minOrNull()
            val max = numArray.maxOrNull()

            tvAnswers.text = "Minimum: $min\n Maximum: $max"
        } else {
            tvAnswers.text = "No Numbers Found."
        }
    }

    private fun Average() {
        if (numArray.isNotEmpty()) {
            var sum = 0
            for (value in numArray) {
                sum += value
            }
            val average = sum.toDouble() / numArray.size
            tvAnswers.text = "Average: $average"
        }
        else {
            tvAnswers.text = "No Numbers Found."
        }
    }

    private fun clear() {
        numArray.fill(0)
    }
}
