package com.nehaar.imadpart1

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        var buttonAdd = findViewById<Button>(R.id.buttonAdd)

        var textResult = findViewById<TextView>(R.id.textResult)

        var editTextNumber1 = findViewById<EditText>(R.id.editTextNumber1)

        var editTextNumber2 = findViewById<EditText>(R.id.editTextNumber2)

        var buttonSub = findViewById<Button>(R.id.buttonSub)

        var buttonMulti = findViewById<Button>(R.id.buttonMulti)

         var buttonDiv = findViewById<Button>(R.id.buttonDiv)

         var buttonPower = findViewById<Button>(R.id.buttonPower)

         var buttonStat = findViewById<Button>(R.id.buttonStat)

        Log.i("Testing","OnCreate Works");

        buttonAdd.setOnClickListener {


           val number1 = editTextNumber1.text.toString().toInt()
            val number2 = editTextNumber2.text.toString().toInt()
            val result = number1 + number2

            val output = "$number1 + $number2 = $result"
            textResult.text = output
        }

        buttonSub.setOnClickListener {
            val number1 = editTextNumber1.text.toString().toInt()
            val number2 = editTextNumber2.text.toString().toInt()
            val result = number1 - number2

            val output = "$number1 - $number2 = $result"
            textResult.text = output
        }

        buttonMulti.setOnClickListener {
            val number1 = editTextNumber1.text.toString().toInt()
            val number2 = editTextNumber2.text.toString().toInt()
            val result = number1 * number2

            val output = "$number1 * $number2 = $result"
            textResult.text = output
        }

        buttonDiv.setOnClickListener {
            val number1 = editTextNumber1.text.toString().toInt()
            val number2 = editTextNumber2.text.toString().toInt()
            val result = number1 / number2

            val output = "$number1 / $number2 = $result"
            textResult.text = output
        }

        buttonStat.setOnClickListener {
            val intent = Intent(this, StatsFunction::class.java)
            startActivity(intent)
        }
        

    }

}